public class Tile {
   
    private int value;
    private String valueStr;
    private String question;
    private String answer;
    private boolean isAnswered;
    static int tCount; //variable for the game while loop in main file
    
//makes a new question tile
    public Tile(String value, String question, String answer)
    {
        this.value = Integer.valueOf(value); //this one stores the actual value
        this.valueStr = value; //this will be printed out as the tile card
        this.question = question;
        this.answer = answer;
        isAnswered = false;
    } 
    
//lets user pick their tile
    public void chooseTile()
    {
        MyProgram.print(question);
    }
//checks if the tile has been answered
    public boolean checkIfAnswered()
    {
        return isAnswered;
    }
//makes chosen tile blank
    public void removeTile()
    {
        isAnswered = true;
        valueStr = "   ";
        tCount++;
    }
//getters
    public String getAnswer()
    {
        return answer;
    }
    public int getValue()
    {
        return value;
    }
    
    public String toString()
    {
        return valueStr;
    }
}