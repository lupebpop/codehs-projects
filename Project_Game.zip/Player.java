public class Player 
{
    private int teamNum;
    private static int teamCount;
    private int teamScore = 0;
    
    
//makes a new team; figure out how to let the player to add teams
    public Player()
    {
        teamNum = teamCount + 1;
        teamCount++;
    }
    
    public int getScore()
    {
        return teamScore;
    }
    
   //adds point to playing team
   public void addPoints(int value)
    {
        MyProgram.print("Right answer, next turn!");
        teamScore += value;
    }
    
    public String toString()
    {
        return "Team " + teamNum + ": " + teamScore;
    }
}