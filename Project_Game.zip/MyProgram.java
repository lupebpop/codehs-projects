import java.util.*;

//make grid bigger (optional)
//optimize tiles into rows (optional)

public class MyProgram
{
    static int countPlay = 1; //keeps track of turns
    
    public static void main(String[] args)
    {
        int winLimit = 1400;
    //objects
        //scanner(obviously)
        Scanner scan = new Scanner(System.in);
        //teams
        Player p1 = new Player();
        Player p2 = new Player();
        //tiles
        Tile t1 = new Tile("200", "What color is a giraffe's tongue?", "Purple"); //cat1-200
        Tile t2 = new Tile("200", "Which everyday condiment found in almost every restaurant throughout the U.S. was first sold as medicine?", "Ketchup"); //cat2-200
        Tile t3 = new Tile("200", "This human body part stays the same size since birth. (answer should be plural)", "Eyeballs"); //cat3-200
        Tile t4 = new Tile("400", "What male sea creature gives birth? (answer should be singular)", "Seahorse"); //cat1-400
        Tile t5 = new Tile("400", "Which writer adapted his own book for the 1989 film \"Pet Sematary\"?", "Stephen King"); //cat2-400
        Tile t6 = new Tile("400", "What is the largest state in the U.S.?", "Alaska"); //cat3-400
        Tile t7 = new Tile("600", "What does HTTP stand for?", "Hypertext Transfer Protocol"); //cat1-600
        Tile t8 = new Tile("600", "What part of the computer holds the Memory and CPU?(answer is two words)", "The motherboard"); //cat2-600
        Tile t9 = new Tile("600", "Besides red, what other color can a stop sign be?", "Green"); //cat3-600
        
        //game loop
        while(!(p1.getScore() >= winLimit || p2.getScore() >= winLimit || Tile.tCount == 9))
        {
            //board setup
            print("_____________________________________");
            print("| Category 1| Category 2| Category 3|");
            print("—————————————————————————————————————");
            System.out.print("|    " + t1 + "    |");
            System.out.print("    "  + t2 + "    |");
            System.out.println("    " + t3 + "    |");
            print("—————————————————————————————————————");
            System.out.print("|    " + t4 + "    |");
            System.out.print("    "  + t5 + "    |");
            System.out.println("    " + t6 + "    |");
            print("—————————————————————————————————————");
            System.out.print("|    " + t7 + "    |");
            System.out.print("    "  + t8 + "    |");
            System.out.println("    " + t9 + "    |");
            print("—————————————————————————————————————");
            print(p1 + "   " + p2);
            System.out.println();
            
            //prints out who's turn it is
            if(countPlay == 1)
            {
                print("It is Team 1's turn!");
            }
            else if(countPlay == 2)
            {
                print("It is Team 2's turn!");
            }
            print("Choose your tile (example input: Cat1-200)");
            String choice = scan.nextLine();
            
            //checking for which tile player chose
            if(choice.equalsIgnoreCase("Cat1-200") && t1.checkIfAnswered() != true)
            {
                int tValue = t1.getValue();
                System.out.println();
                t1.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t1.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t1.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat2-200") && t2.checkIfAnswered() != true)
            {
                int tValue = t2.getValue();
                System.out.println();
                t2.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t2.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t2.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat3-200") && t3.checkIfAnswered() != true)
            {
                int tValue = t3.getValue();
                System.out.println();
                t3.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t3.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t3.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat1-400") && t4.checkIfAnswered() != true)
            {
                int tValue = t4.getValue();
                System.out.println();
                t4.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t4.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t4.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat2-400") && t5.checkIfAnswered() != true)
            {
                int tValue = t5.getValue();
                System.out.println();
                t5.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t5.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t5.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat3-400") && t6.checkIfAnswered() != true)
            {
                int tValue = t6.getValue();
                System.out.println();
                t6.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t6.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t6.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat1-600") && t7.checkIfAnswered() != true)
            {
                int tValue = t7.getValue();
                System.out.println();
                t7.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t7.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t7.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat2-600") && t8.checkIfAnswered() != true)
            {
                int tValue = t8.getValue();
                System.out.println();
                t8.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t8.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t8.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
            if(choice.equalsIgnoreCase("Cat3-600") && t9.checkIfAnswered() != true)
            {
                int tValue = t9.getValue();
                System.out.println();
                t9.chooseTile();
                String answer = scan.nextLine();
                if(answer.equalsIgnoreCase(t9.getAnswer()))
                {
                    if(countPlay == 1)
                    {
                        p1.addPoints(tValue);
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        p2.addPoints(tValue);
                        countPlay--;
                    }
                    t9.removeTile();
                }
                else
                {
                    if(countPlay == 1)
                    {
                        countPlay++;
                    }
                    else if(countPlay == 2)
                    {
                        countPlay--;
                    }
                    print("Wrong answer, next turn!");
                }
            }
            
        }
        
        //game over stuff
        if(p1.getScore() >= winLimit)
        {
            print("Game Over! Team 1 wins with " + p1.getScore() + " points!\nThank you for playing! :)");
        }
        else if(p2.getScore() >= winLimit)
        {
            print("Game Over! Team 2 wins with " + p2.getScore() + " points!\nThank you for playing! :)");
        }
        else if(Tile.tCount == 9) //change number if we add more tiles
        {
            print("Game Over! No one wins. :(\nThanks for playing!");
        }
    }
    
    
    //to make life a little easier :)
    public static void print(String text)
    {
        System.out.println(text);
    }
    
    public static void print(int number)
    {
        System.out.println(number);
    }
    
    public static void print(double number)
    {
        System.out.println(number);
    }
    
    public static void print(Player obj)
    {
        System.out.println(obj);
    }
    
    public static void print(Tile obj)
    {
        System.out.println(obj);
    }
}